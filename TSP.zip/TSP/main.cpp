#include "TSP.h"
#include <iostream>
#include <limits>
#include <assert.h>
#include <chrono>
#include <ctime>
#define max_generationsWithoutImprovement 5e3//改变这个值去控制交配的代数

using namespace std;

int main()
{

    /* mutation probability, mutation probability */
    TSP *tsp = new TSP(0.8, 0.15);
    cout << "(" << tsp->crossoverProbability << "," << tsp->mutationProbability << ")" << endl;
    std::chrono::time_point<std::chrono::system_clock> start, end;/*需要在C++11编译*/
    start = std::chrono::system_clock::now();
    size_t generations = 0, generationsWithoutImprovement = 0;
    double bestFitness = -1;
    /* We'll stop when we've gone 10k generations without improvement */
    cout << "Please wait for computing the solution!" << endl;
    while(generationsWithoutImprovement < max_generationsWithoutImprovement)
    {
        tsp->nextPopulation();
        ++generations;
        double newFitness = tsp->getBestFitness();
        /* The new fitness is higher, the chromosone is better */
        if(newFitness > bestFitness)
        {
            bestFitness = newFitness;
            generationsWithoutImprovement = 0;
            //cout << "Best goal function: " << tsp->getBestFitness() << endl;
        }
        else
        {
            ++generationsWithoutImprovement;
        }
    }


    end = std::chrono::system_clock::now();

    std::chrono::duration<double> elapsed_seconds = end-start;
    std::time_t end_time = std::chrono::system_clock::to_time_t(end);

    std::cout << "elapsed time: " << elapsed_seconds.count() << "s\n";
    cout << "Number of generations: " << generations << endl;
    cout << "Best chromosone info: " << endl;
    cout << "\t-Path: " << tsp->getBestPathString() << endl;
    cout << "\t-Distance: " << tsp->getLowestTotalDistance() << endl;
    delete tsp;
    return 0;
}
